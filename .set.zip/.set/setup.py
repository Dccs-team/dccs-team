from setuptools import setup
setup(name="dccsb",
	version="0.1",
	description= " This tools use tg bot by module ",
	author="Saimun",
	package=["dccsb"],
	zip_safe= False)